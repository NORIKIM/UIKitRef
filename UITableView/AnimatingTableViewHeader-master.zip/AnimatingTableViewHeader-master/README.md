# AnimatingTableViewHeader
A Swift project explaining how to animate a header above a UITableView

Checkout my blog post [here](https://michiganlabs.com/2016/05/31/ios-animating-uitableview-header/)
for details on how this project works!

![Animating Header](https://michiganlabs.com/uploads/blog/posts/demo.gif)

## Additional features not covered in the blog:
* [Stretchy Header](https://github.com/MichiganLabs/AnimatingTableViewHeader/tree/feature/stretchy-header)
